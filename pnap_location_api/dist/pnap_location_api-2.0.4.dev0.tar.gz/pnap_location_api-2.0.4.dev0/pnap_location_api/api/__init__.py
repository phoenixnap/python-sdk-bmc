# flake8: noqa

# import apis into api package
from pnap_location_api.api.locations_api import LocationsApi

